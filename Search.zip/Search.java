import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Search {
	
	
	private String data,find;
	
	private static int resultsfound;

	private static Scanner sc;
	


	public Search() {
		data="RaviKrishnan, SnehaSharma, AmitChandra, KuldeepBhadana, "
				+ "HemantGupta, RichaAgarwal, AmitSharma, Vijay, AmrikSingh, SnehaChandra, "
				+ "SudhirSinha, VanshChoudhary, RichaNagpal, MehakMishra, AmitGupta, RichaMaheswari, "
				+ "AbhishekGulati, AmitChaudhary";
		
		sc = new Scanner(System.in);
		find=sc.nextLine();
		resultsfound=0;
		
	}
	
	public String matchedData(int index){
		
		resultsfound++;
		String result="";
		while(index<data.length()&&data.charAt(index)!=','){
			result+=data.charAt(index);
			index++;
		}
		return result;
		
	}
	
	public void findResult(){
		
		Pattern pattern=Pattern.compile(find+"+",Pattern.CASE_INSENSITIVE);       
		Matcher matcher=pattern.matcher(data);
		
		
		while(matcher.find()){
			
			int start=matcher.start();
			if(start==0||data.charAt(start-1)==' '){
				String result=matchedData(start);
				System.out.println(result);
			}
			
		}
		
		displayCountOfFoundCustomers();

		
	}
	
	public void displayCountOfFoundCustomers(){
		System.out.println("Customers Found - "+resultsfound);
	}

	public static void main(String[] args) {
		Search obj=new Search();
		obj.findResult();

	}

}
